package com.cursoJava.hibernate.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name="address")
public class Address {

	@Id
	@Column(name="id")
	private int id;
	
	@Column(name="type")
	private String type;
	
	@Column(name="name")
	private String name;
	
	@Column(name="number")
	private int number;
	
	@Column(name="city")
	private String city;
	
	@Column(name="zipcode")
	private int zipcode;
	
	@ManyToOne
	@JoinColumn(name="IdStudent")
	private Student student;

	public Address(int id, String type, String name, int number, String city, int zipcode, Student student) {
		super();
		this.id = id;
		this.type = type;
		this.name = name;
		this.number = number;
		this.city = city;
		this.zipcode = zipcode;
		this.student = student;
	}



	public Address(String type, String name, int number, String city, int zipcode) {
		this.type = type;
		this.name = name;
		this.number = number;
		this.city = city;
		this.zipcode = zipcode;
	}

	public Address() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	
	@Override
	public String toString() {
		return "Address [id=" + id + ", type=" + type + ", name=" + name + ", number=" + number + ", city=" + city
				+ ", zipcode=" + zipcode + "]";
	}
	
}
