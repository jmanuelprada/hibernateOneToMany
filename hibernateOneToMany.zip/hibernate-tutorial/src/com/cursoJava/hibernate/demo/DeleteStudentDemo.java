package com.cursoJava.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cursoJava.hibernate.demo.entity.Student;

public class DeleteStudentDemo {

	public static void main(String[] args) {
		
		
		// create session factory
		
		SessionFactory factory = new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Student.class)
								.buildSessionFactory();
		
		// create session
		Session session = factory.getCurrentSession();
		
		try {
			
			int studentId = 1;
		
			//get session and start new transaction
			session = factory.getCurrentSession();
			session.beginTransaction();
			
			System.out.println("\nGetting student with id: " + studentId);
			
			
			
			//Student myStudent = session.get(Student.class, studentId);
			
			//delete Student ID = 1 using delete method
			//System.out.println("Deleting student: " + myStudent);
			//session.delete(myStudent);
			
			//delete Student ID = 2 using createQuery method
			System.out.println("Deleting student id=2");
			session.createQuery("delete from Student where Id = 2").executeUpdate();
			
			//commit the transaction
			session.getTransaction().commit();
			

			System.out.println("Done!");
		}
		finally {
			factory.close();
		}

	}

}
