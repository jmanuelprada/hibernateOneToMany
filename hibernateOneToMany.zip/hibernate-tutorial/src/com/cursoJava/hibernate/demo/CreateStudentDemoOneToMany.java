package com.cursoJava.hibernate.demo;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cursoJava.hibernate.demo.entity.Address;
import com.cursoJava.hibernate.demo.entity.Student;

public class CreateStudentDemoOneToMany {

	public static void main(String[] args) {
		
		
		// create session factory
		
		SessionFactory factory = new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Student.class)
								.buildSessionFactory();
		
		// create session
		Session session = factory.getCurrentSession();
		
		try {
			
			//use the object to save the Java Object
			System.out.println("creating new Student object with address");

			Student tempStudent = new Student (11, "Jose2", "Prada2", "jose.prada@mail.com");
			
			Set<Address> direcciones = new HashSet<>();
			
			//if the row already exists, execute UPDATE, if not execute INSERT
			direcciones.add (new Address(8,"street","high road3333", 200, "Ohio", 15011, tempStudent));
			direcciones.add (new Address(9,"street2","high road3333", 300, "Ohio", 15014,tempStudent));
			direcciones.add (new Address(10,"street3","high road3333", 400, "Michigan", 15019,tempStudent));
			
			tempStudent.setDirecciones(direcciones);
			
			//start a transaction
			session.beginTransaction();
			
			//save the student object
			System.out.println("Saving the student...");
			session.save(tempStudent);
			
			//commit transaction
			session.getTransaction().commit();
			System.out.println("Done!");
		}
		catch (Exception e) {
			System.out.println("Se ha producido una excepcion: " + e.getMessage());
		}
		finally {
			factory.close();
		}

	}

}
